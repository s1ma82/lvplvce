const o=`:root {
    --bg-color: #313131;
    --main-color: #f66e0d;
    --caret-color: #f66e0d;
    --sub-color: #616161;
    --sub-alt-color: #2b2b2b;
    --text-color: #f5e6c8;
    --error-color: #e72d2d;
    --error-extra-color: #7e2a33;
    --colorful-error-color: #e72d2d;
    --colorful-error-extra-color: #7e2a33
}
`;export{o as default};
